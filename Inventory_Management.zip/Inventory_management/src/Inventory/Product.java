package Inventory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Product 
{

	public static void main(String[] args) throws SQLException, ClassNotFoundException 
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory","root","root");
		System.out.println("Connection established");
		
//		Statement statement=connection.createStatement();
//		statement.execute("create database Inventory");
		options();
	}
		static void options() throws SQLException
		{
			System.out.println("Welcome to Inventory management System");
			System.out.println("1. View Product");
			System.out.println("2. Search");
			System.out.println("3. Update");
			System.out.println("4. Add Product");
			Scanner sc=new Scanner(System.in);
			System.out.println();
			System.out.println("Enter option--");
			int no=sc.nextInt();
//			if(no==1)
//			{
//				view_product();
//			}
//			else if(no==2)
//			{
//				search();
//			}
//			else if(no==3)
//			{
//				update();
//			}
//			else if(no==4)
//			{
//				Add_product();
//			}
			
		} 
		
}
